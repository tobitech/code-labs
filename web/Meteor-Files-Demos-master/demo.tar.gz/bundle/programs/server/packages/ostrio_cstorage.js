(function () {



/* Exports */
Package._define("ostrio:cstorage");

})();
