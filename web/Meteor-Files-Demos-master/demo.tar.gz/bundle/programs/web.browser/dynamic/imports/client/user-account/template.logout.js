function(){Template.__checkName("logout"),Template.logout=new Template("Template.logout",function(){var t=this;return HTML.Raw('<a data-logout="" href="#" title="Logout"><i class="la la-lg la-sign-out"></i></a>')})}

