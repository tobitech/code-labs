(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var meteorInstall = Package.modules.meteorInstall;
var ECMAScript = Package.ecmascript.ECMAScript;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var EJSON = Package.ejson.EJSON;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:flow-router-extra":{"server":{"_init.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/server/_init.js                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({
  FlowRouter: () => FlowRouter,
  Router: () => Router,
  Route: () => Route,
  Group: () => Group,
  Triggers: () => Triggers,
  BlazeRenderer: () => BlazeRenderer
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Router;
module.watch(require("./router.js"), {
  default(v) {
    Router = v;
  }

}, 1);
let Route;
module.watch(require("./route.js"), {
  default(v) {
    Route = v;
  }

}, 2);
let Group;
module.watch(require("./group.js"), {
  default(v) {
    Group = v;
  }

}, 3);
module.watch(require("./plugins/fast-render.js"));

if (Package['meteorhacks:inject-data']) {
  Meteor._debug('`meteorhacks:inject-data` is deprecated, please remove it and install its successor - `staringatlights:inject-data`');

  Meteor._debug('meteor remove meteorhacks:inject-data');

  Meteor._debug('meteor add staringatlights:inject-data');
}

if (Package['meteorhacks:fast-render']) {
  Meteor._debug('`meteorhacks:fast-render` is deprecated, please remove it and install its successor - `staringatlights:fast-render`');

  Meteor._debug('meteor remove meteorhacks:fast-render');

  Meteor._debug('meteor add staringatlights:fast-render');
}

const Triggers = {};
const BlazeRenderer = {};
const FlowRouter = new Router();
FlowRouter.Router = Router;
FlowRouter.Route = Route;
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/server/group.js                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let _helpers;

module.watch(require("./../lib/_helpers.js"), {
  _helpers(v) {
    _helpers = v;
  }

}, 0);

const makeTrigger = trigger => {
  if (_helpers.isFunction(trigger)) {
    return [trigger];
  } else if (!_helpers.isArray(trigger)) {
    return [];
  }

  return trigger;
};

const makeTriggers = (_base, _triggers) => {
  if (!_base && !_triggers) {
    return [];
  }

  return makeTrigger(_base).concat(makeTrigger(_triggers));
};

class Group {
  constructor(router, options = {}, parent) {
    if (options.prefix && !/^\//.test(options.prefix)) {
      throw new Error('group\'s prefix must start with "/"');
    }

    this._router = router;
    this.prefix = options.prefix || '';
    this.name = options.name;
    this.options = options;
    this._triggersEnter = makeTriggers(options.triggersEnter, this._triggersEnter);
    this._triggersExit = makeTriggers(this._triggersExit, options.triggersExit);
    this._subscriptions = options.subscriptions || Function.prototype;
    this.parent = parent;

    if (this.parent) {
      this.prefix = parent.prefix + this.prefix;
      this._triggersEnter = makeTriggers(parent._triggersEnter, this._triggersEnter);
      this._triggersExit = makeTriggers(this._triggersExit, parent._triggersExit);
    }
  }

  route(_pathDef, options = {}, _group) {
    if (!/^\//.test(_pathDef)) {
      throw new Error('route\'s path must start with "/"');
    }

    const group = _group || this;
    const pathDef = this.prefix + _pathDef;
    options.triggersEnter = makeTriggers(this._triggersEnter, options.triggersEnter);
    options.triggersExit = makeTriggers(options.triggersExit, this._triggersExit);
    return this._router.route(pathDef, _helpers.extend(_helpers.omit(this.options, ['triggersEnter', 'triggersExit', 'subscriptions', 'prefix', 'waitOn', 'name', 'title', 'titlePrefix', 'link', 'script', 'meta']), options), group);
  }

  group(options) {
    return new Group(this._router, options, this);
  }

}

module.exportDefault(Group);
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"route.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/server/route.js                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
class Route {
  constructor(router, pathDef, options = {}) {
    this.options = options;
    this.name = options.name;
    this.pathDef = pathDef; // Route.path is deprecated and will be removed in 3.0

    this.path = pathDef;
    this.action = options.action || Function.prototype;
    this.subscriptions = options.subscriptions || Function.prototype;
    this._subsMap = {};
  }

  register(name, sub) {
    this._subsMap[name] = sub;
  }

  subscription(name) {
    return this._subsMap[name];
  }

  middleware() {// ?
  }

}

module.exportDefault(Route);
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/server/router.js                                               //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let Route;
module.watch(require("./route.js"), {
  default(v) {
    Route = v;
  }

}, 0);
let Group;
module.watch(require("./group.js"), {
  default(v) {
    Group = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);

let _helpers;

module.watch(require("./../lib/_helpers.js"), {
  _helpers(v) {
    _helpers = v;
  }

}, 3);

const qs = require('qs');

class Router {
  constructor() {
    this.pathRegExp = /(:[\w\(\)\\\+\*\.\?\[\]\-]+)+/g;
    this._routes = [];
    this._routesMap = {};
    this.subscriptions = Function.prototype; // holds onRoute callbacks

    this._onRouteCallbacks = [];
    this.triggers = {
      enter() {// client only
      },

      exit() {// client only
      }

    };
  }

  route(pathDef, options = {}) {
    if (!/^\/.*/.test(pathDef) && pathDef !== '*') {
      throw new Error('route\'s path must start with "/"');
    }

    const route = new Route(this, pathDef, options);

    this._routes.push(route);

    if (options.name) {
      this._routesMap[options.name] = route;
    }

    this._triggerRouteRegister(route);

    return route;
  }

  group(options) {
    return new Group(this, options);
  }

  path(_pathDef, fields = {}, queryParams) {
    let pathDef = _pathDef;

    if (this._routesMap[pathDef]) {
      pathDef = this._routesMap[pathDef].path;
    }

    let path = pathDef.replace(this.pathRegExp, _key => {
      const firstRegexpChar = _key.indexOf('('); // get the content behind : and (\\d+/)


      let key = _key.substring(1, firstRegexpChar > 0 ? firstRegexpChar : undefined); // remove +?*


      key = key.replace(/[\+\*\?]+/g, '');
      return fields[key] || '';
    });
    path = path.replace(/\/\/+/g, '/'); // Replace multiple slashes with single slash
    // remove trailing slash
    // but keep the root slash if it's the only one

    path = path.match(/^\/{1}$/) ? path : path.replace(/\/$/, '');
    const strQueryParams = qs.stringify(queryParams || {});

    if (strQueryParams) {
      path += '?' + strQueryParams;
    }

    return path;
  }

  onRouteRegister(cb) {
    this._onRouteCallbacks.push(cb);
  }

  _triggerRouteRegister(currentRoute) {
    // We should only need to send a safe set of fields on the route
    // object.
    // This is not to hide what's inside the route object, but to show
    // these are the public APIs
    const routePublicApi = _helpers.pick(currentRoute, ['name', 'pathDef', 'path']);

    routePublicApi.options = _helpers.omit(currentRoute.options, ['triggersEnter', 'triggersExit', 'action', 'subscriptions', 'name']);

    this._onRouteCallbacks.forEach(cb => {
      cb(routePublicApi);
    });
  }

  go() {// client only
  }

  current() {// client only
  }

  middleware() {// client only
  }

  getState() {// client only
  }

  getAllStates() {// client only
  }

  setState() {// client only
  }

  removeState() {// client only
  }

  clearStates() {// client only
  }

  ready() {// client only
  }

  initialize() {// client only
  }

  wait() {// client only
  }

  url() {
    // We need to remove the leading base path, or "/", as it will be inserted
    // automatically by `Meteor.absoluteUrl` as documented in:
    // http://docs.meteor.com/#/full/meteor_absoluteurl
    return Meteor.absoluteUrl(this.path.apply(this, arguments).replace(new RegExp('^' + ('/' + (this._basePath || '') + '/').replace(/\/\/+/g, '/')), ''));
  }

}

module.exportDefault(Router);
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"plugins":{"fast-render.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/server/plugins/fast-render.js                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);

let _helpers;

module.watch(require("./../../lib/_helpers.js"), {
  _helpers(v) {
    _helpers = v;
  }

}, 1);
let FlowRouter;
module.watch(require("../_init.js"), {
  FlowRouter(v) {
    FlowRouter = v;
  }

}, 2);

if (!Package['staringatlights:fast-render']) {
  return;
}

const FastRender = Package['staringatlights:fast-render'].FastRender;

const setupFastRender = () => {
  FlowRouter._routes.forEach(route => {
    if (route.pathDef === '*') {
      return;
    }

    FastRender.route(route.pathDef, function (routeParams, path) {
      // anyone using Meteor.subscribe for something else?
      const meteorSubscribe = Meteor.subscribe;

      Meteor.subscribe = function () {
        return Array.from(arguments);
      };

      route._subsMap = {};
      FlowRouter.subscriptions.call(route, path);

      if (route.subscriptions) {
        route.subscriptions(_helpers.omit(routeParams, ['query']), routeParams.query);
      }

      Object.keys(route._subsMap).forEach(key => {
        this.subscribe.apply(this, route._subsMap[key]);
      }); // restore Meteor.subscribe, ... on server side

      Meteor.subscribe = meteorSubscribe;
    });
  });
}; // hack to run after everything else on startup


Meteor.startup(() => {
  Meteor.startup(() => {
    setupFastRender();
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"lib":{"_helpers.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// packages/ostrio_flow-router-extra/lib/_helpers.js                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({
  _helpers: () => _helpers
});
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
const _helpers = {
  isEmpty(obj) {
    // 1
    if (obj == null) {
      return true;
    }

    if (this.isArray(obj) || this.isString(obj) || this.isArguments(obj)) {
      return obj.length === 0;
    }

    return Object.keys(obj).length === 0;
  },

  isObject(obj) {
    const type = typeof obj;
    return type === 'function' || type === 'object' && !!obj;
  },

  omit(obj, keys) {
    // 10
    if (!this.isObject(obj)) {
      Meteor._debug('[ostrio:flow-router-extra] [_helpers.omit] First argument must be an Object');

      return obj;
    }

    if (!this.isArray(keys)) {
      Meteor._debug('[ostrio:flow-router-extra] [_helpers.omit] Second argument must be an Array');

      return obj;
    }

    const copy = this.clone(obj);
    keys.forEach(key => {
      delete copy[key];
    });
    return copy;
  },

  pick(obj, keys) {
    // 2
    if (!this.isObject(obj)) {
      Meteor._debug('[ostrio:flow-router-extra] [_helpers.omit] First argument must be an Object');

      return obj;
    }

    if (!this.isArray(keys)) {
      Meteor._debug('[ostrio:flow-router-extra] [_helpers.omit] Second argument must be an Array');

      return obj;
    }

    const picked = {};
    keys.forEach(key => {
      picked[key] = obj[key];
    });
    return picked;
  },

  isArray(obj) {
    return Array.isArray(obj);
  },

  extend(...objs) {
    // 4
    return Object.assign({}, ...objs);
  },

  clone(obj) {
    if (!this.isObject(obj)) return obj;
    return this.isArray(obj) ? obj.slice() : this.extend(obj);
  }

};
['Arguments', 'Function', 'String', 'RegExp'].forEach(name => {
  _helpers['is' + name] = function (obj) {
    return Object.prototype.toString.call(obj) === '[object ' + name + ']';
  };
});
//////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"qs":{"package.json":function(require,exports){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// node_modules/meteor/ostrio_flow-router-extra/node_modules/qs/package.json                        //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
exports.name = "qs";
exports.version = "6.5.2";
exports.main = "lib/index.js";

//////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"index.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// node_modules/meteor/ostrio_flow-router-extra/node_modules/qs/lib/index.js                        //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.useNode();
//////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
var exports = require("/node_modules/meteor/ostrio:flow-router-extra/server/_init.js");

/* Exports */
Package._define("ostrio:flow-router-extra", exports);

})();

//# sourceURL=meteor://💻app/packages/ostrio_flow-router-extra.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhL3NlcnZlci9faW5pdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhL3NlcnZlci9ncm91cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhL3NlcnZlci9yb3V0ZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhL3NlcnZlci9yb3V0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL29zdHJpbzpmbG93LXJvdXRlci1leHRyYS9zZXJ2ZXIvcGx1Z2lucy9mYXN0LXJlbmRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhL2xpYi9faGVscGVycy5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnQiLCJGbG93Um91dGVyIiwiUm91dGVyIiwiUm91dGUiLCJHcm91cCIsIlRyaWdnZXJzIiwiQmxhemVSZW5kZXJlciIsIk1ldGVvciIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJkZWZhdWx0IiwiUGFja2FnZSIsIl9kZWJ1ZyIsIl9oZWxwZXJzIiwibWFrZVRyaWdnZXIiLCJ0cmlnZ2VyIiwiaXNGdW5jdGlvbiIsImlzQXJyYXkiLCJtYWtlVHJpZ2dlcnMiLCJfYmFzZSIsIl90cmlnZ2VycyIsImNvbmNhdCIsImNvbnN0cnVjdG9yIiwicm91dGVyIiwib3B0aW9ucyIsInBhcmVudCIsInByZWZpeCIsInRlc3QiLCJFcnJvciIsIl9yb3V0ZXIiLCJuYW1lIiwiX3RyaWdnZXJzRW50ZXIiLCJ0cmlnZ2Vyc0VudGVyIiwiX3RyaWdnZXJzRXhpdCIsInRyaWdnZXJzRXhpdCIsIl9zdWJzY3JpcHRpb25zIiwic3Vic2NyaXB0aW9ucyIsIkZ1bmN0aW9uIiwicHJvdG90eXBlIiwicm91dGUiLCJfcGF0aERlZiIsIl9ncm91cCIsImdyb3VwIiwicGF0aERlZiIsImV4dGVuZCIsIm9taXQiLCJleHBvcnREZWZhdWx0IiwicGF0aCIsImFjdGlvbiIsIl9zdWJzTWFwIiwicmVnaXN0ZXIiLCJzdWIiLCJzdWJzY3JpcHRpb24iLCJtaWRkbGV3YXJlIiwicXMiLCJwYXRoUmVnRXhwIiwiX3JvdXRlcyIsIl9yb3V0ZXNNYXAiLCJfb25Sb3V0ZUNhbGxiYWNrcyIsInRyaWdnZXJzIiwiZW50ZXIiLCJleGl0IiwicHVzaCIsIl90cmlnZ2VyUm91dGVSZWdpc3RlciIsImZpZWxkcyIsInF1ZXJ5UGFyYW1zIiwicmVwbGFjZSIsIl9rZXkiLCJmaXJzdFJlZ2V4cENoYXIiLCJpbmRleE9mIiwia2V5Iiwic3Vic3RyaW5nIiwidW5kZWZpbmVkIiwibWF0Y2giLCJzdHJRdWVyeVBhcmFtcyIsInN0cmluZ2lmeSIsIm9uUm91dGVSZWdpc3RlciIsImNiIiwiY3VycmVudFJvdXRlIiwicm91dGVQdWJsaWNBcGkiLCJwaWNrIiwiZm9yRWFjaCIsImdvIiwiY3VycmVudCIsImdldFN0YXRlIiwiZ2V0QWxsU3RhdGVzIiwic2V0U3RhdGUiLCJyZW1vdmVTdGF0ZSIsImNsZWFyU3RhdGVzIiwicmVhZHkiLCJpbml0aWFsaXplIiwid2FpdCIsInVybCIsImFic29sdXRlVXJsIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJSZWdFeHAiLCJfYmFzZVBhdGgiLCJGYXN0UmVuZGVyIiwic2V0dXBGYXN0UmVuZGVyIiwicm91dGVQYXJhbXMiLCJtZXRlb3JTdWJzY3JpYmUiLCJzdWJzY3JpYmUiLCJBcnJheSIsImZyb20iLCJjYWxsIiwicXVlcnkiLCJPYmplY3QiLCJrZXlzIiwic3RhcnR1cCIsImlzRW1wdHkiLCJvYmoiLCJpc1N0cmluZyIsImlzQXJndW1lbnRzIiwibGVuZ3RoIiwiaXNPYmplY3QiLCJ0eXBlIiwiY29weSIsImNsb25lIiwicGlja2VkIiwib2JqcyIsImFzc2lnbiIsInNsaWNlIiwidG9TdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxPQUFPQyxNQUFQLENBQWM7QUFBQ0MsY0FBVyxNQUFJQSxVQUFoQjtBQUEyQkMsVUFBTyxNQUFJQSxNQUF0QztBQUE2Q0MsU0FBTSxNQUFJQSxLQUF2RDtBQUE2REMsU0FBTSxNQUFJQSxLQUF2RTtBQUE2RUMsWUFBUyxNQUFJQSxRQUExRjtBQUFtR0MsaUJBQWMsTUFBSUE7QUFBckgsQ0FBZDtBQUFtSixJQUFJQyxNQUFKO0FBQVdSLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVIsTUFBSjtBQUFXSCxPQUFPUyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNFLFVBQVFELENBQVIsRUFBVTtBQUFDUixhQUFPUSxDQUFQO0FBQVM7O0FBQXJCLENBQXBDLEVBQTJELENBQTNEO0FBQThELElBQUlQLEtBQUo7QUFBVUosT0FBT1MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDRSxVQUFRRCxDQUFSLEVBQVU7QUFBQ1AsWUFBTU8sQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJTixLQUFKO0FBQVVMLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0UsVUFBUUQsQ0FBUixFQUFVO0FBQUNOLFlBQU1NLENBQU47QUFBUTs7QUFBcEIsQ0FBbkMsRUFBeUQsQ0FBekQ7QUFBNERYLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiOztBQU1sYixJQUFJRyxRQUFRLHlCQUFSLENBQUosRUFBd0M7QUFDdENMLFNBQU9NLE1BQVAsQ0FBYyxxSEFBZDs7QUFDQU4sU0FBT00sTUFBUCxDQUFjLHVDQUFkOztBQUNBTixTQUFPTSxNQUFQLENBQWMsd0NBQWQ7QUFDRDs7QUFFRCxJQUFJRCxRQUFRLHlCQUFSLENBQUosRUFBd0M7QUFDdENMLFNBQU9NLE1BQVAsQ0FBYyxxSEFBZDs7QUFDQU4sU0FBT00sTUFBUCxDQUFjLHVDQUFkOztBQUNBTixTQUFPTSxNQUFQLENBQWMsd0NBQWQ7QUFDRDs7QUFFRCxNQUFNUixXQUFXLEVBQWpCO0FBQ0EsTUFBTUMsZ0JBQWdCLEVBQXRCO0FBRUEsTUFBTUwsYUFBYSxJQUFJQyxNQUFKLEVBQW5CO0FBQ0FELFdBQVdDLE1BQVgsR0FBb0JBLE1BQXBCO0FBQ0FELFdBQVdFLEtBQVgsR0FBbUJBLEtBQW5CLEM7Ozs7Ozs7Ozs7O0FDdkJBLElBQUlXLFFBQUo7O0FBQWFmLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNLLFdBQVNKLENBQVQsRUFBVztBQUFDSSxlQUFTSixDQUFUO0FBQVc7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFOztBQUViLE1BQU1LLGNBQWVDLE9BQUQsSUFBYTtBQUMvQixNQUFJRixTQUFTRyxVQUFULENBQW9CRCxPQUFwQixDQUFKLEVBQWtDO0FBQ2hDLFdBQU8sQ0FBQ0EsT0FBRCxDQUFQO0FBQ0QsR0FGRCxNQUVPLElBQUksQ0FBQ0YsU0FBU0ksT0FBVCxDQUFpQkYsT0FBakIsQ0FBTCxFQUFnQztBQUNyQyxXQUFPLEVBQVA7QUFDRDs7QUFFRCxTQUFPQSxPQUFQO0FBQ0QsQ0FSRDs7QUFVQSxNQUFNRyxlQUFlLENBQUNDLEtBQUQsRUFBUUMsU0FBUixLQUFzQjtBQUN6QyxNQUFLLENBQUNELEtBQUQsSUFBVSxDQUFDQyxTQUFoQixFQUE0QjtBQUMxQixXQUFPLEVBQVA7QUFDRDs7QUFDRCxTQUFPTixZQUFZSyxLQUFaLEVBQW1CRSxNQUFuQixDQUEwQlAsWUFBWU0sU0FBWixDQUExQixDQUFQO0FBQ0QsQ0FMRDs7QUFPQSxNQUFNakIsS0FBTixDQUFZO0FBQ1ZtQixjQUFZQyxNQUFaLEVBQW9CQyxVQUFVLEVBQTlCLEVBQWtDQyxNQUFsQyxFQUEwQztBQUN4QyxRQUFJRCxRQUFRRSxNQUFSLElBQWtCLENBQUMsTUFBTUMsSUFBTixDQUFXSCxRQUFRRSxNQUFuQixDQUF2QixFQUFtRDtBQUNqRCxZQUFNLElBQUlFLEtBQUosQ0FBVSxxQ0FBVixDQUFOO0FBQ0Q7O0FBRUQsU0FBS0MsT0FBTCxHQUFlTixNQUFmO0FBQ0EsU0FBS0csTUFBTCxHQUFjRixRQUFRRSxNQUFSLElBQWtCLEVBQWhDO0FBQ0EsU0FBS0ksSUFBTCxHQUFZTixRQUFRTSxJQUFwQjtBQUNBLFNBQUtOLE9BQUwsR0FBZUEsT0FBZjtBQUVBLFNBQUtPLGNBQUwsR0FBc0JiLGFBQWFNLFFBQVFRLGFBQXJCLEVBQW9DLEtBQUtELGNBQXpDLENBQXRCO0FBQ0EsU0FBS0UsYUFBTCxHQUFzQmYsYUFBYSxLQUFLZSxhQUFsQixFQUFpQ1QsUUFBUVUsWUFBekMsQ0FBdEI7QUFFQSxTQUFLQyxjQUFMLEdBQXNCWCxRQUFRWSxhQUFSLElBQXlCQyxTQUFTQyxTQUF4RDtBQUVBLFNBQUtiLE1BQUwsR0FBY0EsTUFBZDs7QUFDQSxRQUFJLEtBQUtBLE1BQVQsRUFBaUI7QUFDZixXQUFLQyxNQUFMLEdBQWNELE9BQU9DLE1BQVAsR0FBZ0IsS0FBS0EsTUFBbkM7QUFDQSxXQUFLSyxjQUFMLEdBQXNCYixhQUFhTyxPQUFPTSxjQUFwQixFQUFvQyxLQUFLQSxjQUF6QyxDQUF0QjtBQUNBLFdBQUtFLGFBQUwsR0FBc0JmLGFBQWEsS0FBS2UsYUFBbEIsRUFBaUNSLE9BQU9RLGFBQXhDLENBQXRCO0FBQ0Q7QUFDRjs7QUFFRE0sUUFBTUMsUUFBTixFQUFnQmhCLFVBQVUsRUFBMUIsRUFBOEJpQixNQUE5QixFQUFzQztBQUNwQyxRQUFJLENBQUMsTUFBTWQsSUFBTixDQUFXYSxRQUFYLENBQUwsRUFBMkI7QUFDekIsWUFBTSxJQUFJWixLQUFKLENBQVUsbUNBQVYsQ0FBTjtBQUNEOztBQUVELFVBQU1jLFFBQVVELFVBQVUsSUFBMUI7QUFDQSxVQUFNRSxVQUFVLEtBQUtqQixNQUFMLEdBQWNjLFFBQTlCO0FBRUFoQixZQUFRUSxhQUFSLEdBQXdCZCxhQUFhLEtBQUthLGNBQWxCLEVBQWtDUCxRQUFRUSxhQUExQyxDQUF4QjtBQUNBUixZQUFRVSxZQUFSLEdBQXdCaEIsYUFBYU0sUUFBUVUsWUFBckIsRUFBbUMsS0FBS0QsYUFBeEMsQ0FBeEI7QUFFQSxXQUFPLEtBQUtKLE9BQUwsQ0FBYVUsS0FBYixDQUFtQkksT0FBbkIsRUFBNEI5QixTQUFTK0IsTUFBVCxDQUFnQi9CLFNBQVNnQyxJQUFULENBQWMsS0FBS3JCLE9BQW5CLEVBQTRCLENBQUMsZUFBRCxFQUFrQixjQUFsQixFQUFrQyxlQUFsQyxFQUFtRCxRQUFuRCxFQUE2RCxRQUE3RCxFQUF1RSxNQUF2RSxFQUErRSxPQUEvRSxFQUF3RixhQUF4RixFQUF1RyxNQUF2RyxFQUErRyxRQUEvRyxFQUF5SCxNQUF6SCxDQUE1QixDQUFoQixFQUErS0EsT0FBL0ssQ0FBNUIsRUFBcU5rQixLQUFyTixDQUFQO0FBQ0Q7O0FBRURBLFFBQU1sQixPQUFOLEVBQWU7QUFDYixXQUFPLElBQUlyQixLQUFKLENBQVUsS0FBSzBCLE9BQWYsRUFBd0JMLE9BQXhCLEVBQWlDLElBQWpDLENBQVA7QUFDRDs7QUF4Q1M7O0FBbkJaMUIsT0FBT2dELGFBQVAsQ0E4RGUzQyxLQTlEZixFOzs7Ozs7Ozs7OztBQ0FBLE1BQU1ELEtBQU4sQ0FBWTtBQUNWb0IsY0FBWUMsTUFBWixFQUFvQm9CLE9BQXBCLEVBQTZCbkIsVUFBVSxFQUF2QyxFQUEyQztBQUN6QyxTQUFLQSxPQUFMLEdBQWVBLE9BQWY7QUFDQSxTQUFLTSxJQUFMLEdBQVlOLFFBQVFNLElBQXBCO0FBQ0EsU0FBS2EsT0FBTCxHQUFlQSxPQUFmLENBSHlDLENBS3pDOztBQUNBLFNBQUtJLElBQUwsR0FBWUosT0FBWjtBQUVBLFNBQUtLLE1BQUwsR0FBY3hCLFFBQVF3QixNQUFSLElBQWtCWCxTQUFTQyxTQUF6QztBQUNBLFNBQUtGLGFBQUwsR0FBcUJaLFFBQVFZLGFBQVIsSUFBeUJDLFNBQVNDLFNBQXZEO0FBQ0EsU0FBS1csUUFBTCxHQUFnQixFQUFoQjtBQUNEOztBQUdEQyxXQUFTcEIsSUFBVCxFQUFlcUIsR0FBZixFQUFvQjtBQUNsQixTQUFLRixRQUFMLENBQWNuQixJQUFkLElBQXNCcUIsR0FBdEI7QUFDRDs7QUFHREMsZUFBYXRCLElBQWIsRUFBbUI7QUFDakIsV0FBTyxLQUFLbUIsUUFBTCxDQUFjbkIsSUFBZCxDQUFQO0FBQ0Q7O0FBR0R1QixlQUFhLENBQ1g7QUFDRDs7QUEzQlM7O0FBQVp2RCxPQUFPZ0QsYUFBUCxDQThCZTVDLEtBOUJmLEU7Ozs7Ozs7Ozs7O0FDQUEsSUFBSUEsS0FBSjtBQUFVSixPQUFPUyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNFLFVBQVFELENBQVIsRUFBVTtBQUFDUCxZQUFNTyxDQUFOO0FBQVE7O0FBQXBCLENBQW5DLEVBQXlELENBQXpEO0FBQTRELElBQUlOLEtBQUo7QUFBVUwsT0FBT1MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDRSxVQUFRRCxDQUFSLEVBQVU7QUFBQ04sWUFBTU0sQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJSCxNQUFKO0FBQVdSLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0YsU0FBT0csQ0FBUCxFQUFTO0FBQUNILGFBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBQStELElBQUlJLFFBQUo7O0FBQWFmLE9BQU9TLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEVBQTZDO0FBQUNLLFdBQVNKLENBQVQsRUFBVztBQUFDSSxlQUFTSixDQUFUO0FBQVc7O0FBQXhCLENBQTdDLEVBQXVFLENBQXZFOztBQUtuTyxNQUFNNkMsS0FBSzlDLFFBQVEsSUFBUixDQUFYOztBQUVBLE1BQU1QLE1BQU4sQ0FBYTtBQUNYcUIsZ0JBQWM7QUFDWixTQUFLaUMsVUFBTCxHQUFrQixnQ0FBbEI7QUFDQSxTQUFLQyxPQUFMLEdBQWUsRUFBZjtBQUNBLFNBQUtDLFVBQUwsR0FBa0IsRUFBbEI7QUFDQSxTQUFLckIsYUFBTCxHQUFxQkMsU0FBU0MsU0FBOUIsQ0FKWSxDQU1aOztBQUNBLFNBQUtvQixpQkFBTCxHQUF5QixFQUF6QjtBQUVBLFNBQUtDLFFBQUwsR0FBZ0I7QUFDZEMsY0FBUSxDQUNOO0FBQ0QsT0FIYTs7QUFJZEMsYUFBTyxDQUNMO0FBQ0Q7O0FBTmEsS0FBaEI7QUFRRDs7QUFFRHRCLFFBQU1JLE9BQU4sRUFBZW5CLFVBQVUsRUFBekIsRUFBNkI7QUFDM0IsUUFBSSxDQUFDLFFBQVFHLElBQVIsQ0FBYWdCLE9BQWIsQ0FBRCxJQUEwQkEsWUFBWSxHQUExQyxFQUErQztBQUM3QyxZQUFNLElBQUlmLEtBQUosQ0FBVSxtQ0FBVixDQUFOO0FBQ0Q7O0FBRUQsVUFBTVcsUUFBUSxJQUFJckMsS0FBSixDQUFVLElBQVYsRUFBZ0J5QyxPQUFoQixFQUF5Qm5CLE9BQXpCLENBQWQ7O0FBQ0EsU0FBS2dDLE9BQUwsQ0FBYU0sSUFBYixDQUFrQnZCLEtBQWxCOztBQUVBLFFBQUlmLFFBQVFNLElBQVosRUFBa0I7QUFDaEIsV0FBSzJCLFVBQUwsQ0FBZ0JqQyxRQUFRTSxJQUF4QixJQUFnQ1MsS0FBaEM7QUFDRDs7QUFFRCxTQUFLd0IscUJBQUwsQ0FBMkJ4QixLQUEzQjs7QUFDQSxXQUFPQSxLQUFQO0FBQ0Q7O0FBRURHLFFBQU1sQixPQUFOLEVBQWU7QUFDYixXQUFPLElBQUlyQixLQUFKLENBQVUsSUFBVixFQUFnQnFCLE9BQWhCLENBQVA7QUFDRDs7QUFFRHVCLE9BQUtQLFFBQUwsRUFBZXdCLFNBQVMsRUFBeEIsRUFBNEJDLFdBQTVCLEVBQXlDO0FBQ3ZDLFFBQUl0QixVQUFVSCxRQUFkOztBQUNBLFFBQUksS0FBS2lCLFVBQUwsQ0FBZ0JkLE9BQWhCLENBQUosRUFBOEI7QUFDNUJBLGdCQUFVLEtBQUtjLFVBQUwsQ0FBZ0JkLE9BQWhCLEVBQXlCSSxJQUFuQztBQUNEOztBQUVELFFBQUlBLE9BQU9KLFFBQVF1QixPQUFSLENBQWdCLEtBQUtYLFVBQXJCLEVBQWtDWSxJQUFELElBQVU7QUFDcEQsWUFBTUMsa0JBQWtCRCxLQUFLRSxPQUFMLENBQWEsR0FBYixDQUF4QixDQURvRCxDQUVwRDs7O0FBQ0EsVUFBSUMsTUFBTUgsS0FBS0ksU0FBTCxDQUFlLENBQWYsRUFBbUJILGtCQUFrQixDQUFuQixHQUF3QkEsZUFBeEIsR0FBMENJLFNBQTVELENBQVYsQ0FIb0QsQ0FJcEQ7OztBQUNBRixZQUFNQSxJQUFJSixPQUFKLENBQVksWUFBWixFQUEwQixFQUExQixDQUFOO0FBRUEsYUFBT0YsT0FBT00sR0FBUCxLQUFlLEVBQXRCO0FBQ0QsS0FSVSxDQUFYO0FBVUF2QixXQUFPQSxLQUFLbUIsT0FBTCxDQUFhLFFBQWIsRUFBdUIsR0FBdkIsQ0FBUCxDQWhCdUMsQ0FnQkg7QUFFcEM7QUFDQTs7QUFDQW5CLFdBQU9BLEtBQUswQixLQUFMLENBQVcsU0FBWCxJQUF3QjFCLElBQXhCLEdBQStCQSxLQUFLbUIsT0FBTCxDQUFhLEtBQWIsRUFBb0IsRUFBcEIsQ0FBdEM7QUFFQSxVQUFNUSxpQkFBaUJwQixHQUFHcUIsU0FBSCxDQUFhVixlQUFlLEVBQTVCLENBQXZCOztBQUNBLFFBQUdTLGNBQUgsRUFBbUI7QUFDakIzQixjQUFRLE1BQU0yQixjQUFkO0FBQ0Q7O0FBRUQsV0FBTzNCLElBQVA7QUFDRDs7QUFFRDZCLGtCQUFnQkMsRUFBaEIsRUFBb0I7QUFDbEIsU0FBS25CLGlCQUFMLENBQXVCSSxJQUF2QixDQUE0QmUsRUFBNUI7QUFDRDs7QUFFRGQsd0JBQXNCZSxZQUF0QixFQUFvQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQU1DLGlCQUFpQmxFLFNBQVNtRSxJQUFULENBQWNGLFlBQWQsRUFBNEIsQ0FBQyxNQUFELEVBQVMsU0FBVCxFQUFvQixNQUFwQixDQUE1QixDQUF2Qjs7QUFDQUMsbUJBQWV2RCxPQUFmLEdBQXlCWCxTQUFTZ0MsSUFBVCxDQUFjaUMsYUFBYXRELE9BQTNCLEVBQW9DLENBQUMsZUFBRCxFQUFrQixjQUFsQixFQUFrQyxRQUFsQyxFQUE0QyxlQUE1QyxFQUE2RCxNQUE3RCxDQUFwQyxDQUF6Qjs7QUFFQSxTQUFLa0MsaUJBQUwsQ0FBdUJ1QixPQUF2QixDQUFnQ0osRUFBRCxJQUFRO0FBQ3JDQSxTQUFHRSxjQUFIO0FBQ0QsS0FGRDtBQUdEOztBQUdERyxPQUFLLENBQ0g7QUFDRDs7QUFHREMsWUFBVSxDQUNSO0FBQ0Q7O0FBRUQ5QixlQUFhLENBQ1g7QUFDRDs7QUFHRCtCLGFBQVcsQ0FDVDtBQUNEOztBQUdEQyxpQkFBZSxDQUNiO0FBQ0Q7O0FBR0RDLGFBQVcsQ0FDVDtBQUNEOztBQUdEQyxnQkFBYyxDQUNaO0FBQ0Q7O0FBR0RDLGdCQUFjLENBQ1o7QUFDRDs7QUFHREMsVUFBUSxDQUNOO0FBQ0Q7O0FBR0RDLGVBQWEsQ0FDWDtBQUNEOztBQUVEQyxTQUFPLENBQ0w7QUFDRDs7QUFFREMsUUFBTTtBQUNKO0FBQ0E7QUFDQTtBQUNBLFdBQU90RixPQUFPdUYsV0FBUCxDQUFtQixLQUFLOUMsSUFBTCxDQUFVK0MsS0FBVixDQUFnQixJQUFoQixFQUFzQkMsU0FBdEIsRUFBaUM3QixPQUFqQyxDQUF5QyxJQUFJOEIsTUFBSixDQUFXLE1BQU0sQ0FBQyxPQUFPLEtBQUtDLFNBQUwsSUFBa0IsRUFBekIsSUFBK0IsR0FBaEMsRUFBcUMvQixPQUFyQyxDQUE2QyxRQUE3QyxFQUF1RCxHQUF2RCxDQUFqQixDQUF6QyxFQUF3SCxFQUF4SCxDQUFuQixDQUFQO0FBQ0Q7O0FBakpVOztBQVBicEUsT0FBT2dELGFBQVAsQ0EySmU3QyxNQTNKZixFOzs7Ozs7Ozs7OztBQ0FBLElBQUlLLE1BQUo7QUFBV1IsT0FBT1MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFBK0QsSUFBSUksUUFBSjs7QUFBYWYsT0FBT1MsS0FBUCxDQUFhQyxRQUFRLHlCQUFSLENBQWIsRUFBZ0Q7QUFBQ0ssV0FBU0osQ0FBVCxFQUFXO0FBQUNJLGVBQVNKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBaEQsRUFBMEUsQ0FBMUU7QUFBNkUsSUFBSVQsVUFBSjtBQUFlRixPQUFPUyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNSLGFBQVdTLENBQVgsRUFBYTtBQUFDVCxpQkFBV1MsQ0FBWDtBQUFhOztBQUE1QixDQUFwQyxFQUFrRSxDQUFsRTs7QUFJbkwsSUFBRyxDQUFDRSxRQUFRLDZCQUFSLENBQUosRUFBNEM7QUFDMUM7QUFDRDs7QUFFRCxNQUFNdUYsYUFBYXZGLFFBQVEsNkJBQVIsRUFBdUN1RixVQUExRDs7QUFFQSxNQUFNQyxrQkFBa0IsTUFBTTtBQUM1Qm5HLGFBQVd3RCxPQUFYLENBQW1CeUIsT0FBbkIsQ0FBNEIxQyxLQUFELElBQVc7QUFDcEMsUUFBSUEsTUFBTUksT0FBTixLQUFrQixHQUF0QixFQUEyQjtBQUN6QjtBQUNEOztBQUVEdUQsZUFBVzNELEtBQVgsQ0FBaUJBLE1BQU1JLE9BQXZCLEVBQWdDLFVBQVV5RCxXQUFWLEVBQXVCckQsSUFBdkIsRUFBNkI7QUFDM0Q7QUFDQSxZQUFNc0Qsa0JBQWtCL0YsT0FBT2dHLFNBQS9COztBQUNBaEcsYUFBT2dHLFNBQVAsR0FBbUIsWUFBWTtBQUM3QixlQUFPQyxNQUFNQyxJQUFOLENBQVdULFNBQVgsQ0FBUDtBQUNELE9BRkQ7O0FBSUF4RCxZQUFNVSxRQUFOLEdBQWlCLEVBQWpCO0FBQ0FqRCxpQkFBV29DLGFBQVgsQ0FBeUJxRSxJQUF6QixDQUE4QmxFLEtBQTlCLEVBQXFDUSxJQUFyQzs7QUFDQSxVQUFJUixNQUFNSCxhQUFWLEVBQXlCO0FBQ3ZCRyxjQUFNSCxhQUFOLENBQW9CdkIsU0FBU2dDLElBQVQsQ0FBY3VELFdBQWQsRUFBMkIsQ0FBQyxPQUFELENBQTNCLENBQXBCLEVBQTJEQSxZQUFZTSxLQUF2RTtBQUNEOztBQUVEQyxhQUFPQyxJQUFQLENBQVlyRSxNQUFNVSxRQUFsQixFQUE0QmdDLE9BQTVCLENBQXFDWCxHQUFELElBQVM7QUFDM0MsYUFBS2dDLFNBQUwsQ0FBZVIsS0FBZixDQUFxQixJQUFyQixFQUEyQnZELE1BQU1VLFFBQU4sQ0FBZXFCLEdBQWYsQ0FBM0I7QUFDRCxPQUZELEVBYjJELENBaUIzRDs7QUFDQWhFLGFBQU9nRyxTQUFQLEdBQW1CRCxlQUFuQjtBQUNELEtBbkJEO0FBb0JELEdBekJEO0FBMEJELENBM0JELEMsQ0E2QkE7OztBQUNBL0YsT0FBT3VHLE9BQVAsQ0FBZSxNQUFNO0FBQ25CdkcsU0FBT3VHLE9BQVAsQ0FBZSxNQUFNO0FBQ25CVjtBQUNELEdBRkQ7QUFHRCxDQUpELEU7Ozs7Ozs7Ozs7O0FDeENBckcsT0FBT0MsTUFBUCxDQUFjO0FBQUNjLFlBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlQLE1BQUo7QUFBV1IsT0FBT1MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixTQUFPRyxDQUFQLEVBQVM7QUFBQ0gsYUFBT0csQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUVsRCxNQUFNSSxXQUFXO0FBQ2ZpRyxVQUFRQyxHQUFSLEVBQWE7QUFBRTtBQUNiLFFBQUlBLE9BQU8sSUFBWCxFQUFpQjtBQUNmLGFBQU8sSUFBUDtBQUNEOztBQUVELFFBQUksS0FBSzlGLE9BQUwsQ0FBYThGLEdBQWIsS0FBcUIsS0FBS0MsUUFBTCxDQUFjRCxHQUFkLENBQXJCLElBQTJDLEtBQUtFLFdBQUwsQ0FBaUJGLEdBQWpCLENBQS9DLEVBQXNFO0FBQ3BFLGFBQU9BLElBQUlHLE1BQUosS0FBZSxDQUF0QjtBQUNEOztBQUVELFdBQU9QLE9BQU9DLElBQVAsQ0FBWUcsR0FBWixFQUFpQkcsTUFBakIsS0FBNEIsQ0FBbkM7QUFDRCxHQVhjOztBQVlmQyxXQUFTSixHQUFULEVBQWM7QUFDWixVQUFNSyxPQUFPLE9BQU9MLEdBQXBCO0FBQ0EsV0FBT0ssU0FBUyxVQUFULElBQXVCQSxTQUFTLFFBQVQsSUFBcUIsQ0FBQyxDQUFDTCxHQUFyRDtBQUNELEdBZmM7O0FBZ0JmbEUsT0FBS2tFLEdBQUwsRUFBVUgsSUFBVixFQUFnQjtBQUFFO0FBQ2hCLFFBQUksQ0FBQyxLQUFLTyxRQUFMLENBQWNKLEdBQWQsQ0FBTCxFQUF5QjtBQUN2QnpHLGFBQU9NLE1BQVAsQ0FBYyw2RUFBZDs7QUFDQSxhQUFPbUcsR0FBUDtBQUNEOztBQUVELFFBQUksQ0FBQyxLQUFLOUYsT0FBTCxDQUFhMkYsSUFBYixDQUFMLEVBQXlCO0FBQ3ZCdEcsYUFBT00sTUFBUCxDQUFjLDZFQUFkOztBQUNBLGFBQU9tRyxHQUFQO0FBQ0Q7O0FBRUQsVUFBTU0sT0FBTyxLQUFLQyxLQUFMLENBQVdQLEdBQVgsQ0FBYjtBQUNBSCxTQUFLM0IsT0FBTCxDQUFjWCxHQUFELElBQVM7QUFDcEIsYUFBTytDLEtBQUsvQyxHQUFMLENBQVA7QUFDRCxLQUZEO0FBSUEsV0FBTytDLElBQVA7QUFDRCxHQWpDYzs7QUFrQ2ZyQyxPQUFLK0IsR0FBTCxFQUFVSCxJQUFWLEVBQWdCO0FBQUU7QUFDaEIsUUFBSSxDQUFDLEtBQUtPLFFBQUwsQ0FBY0osR0FBZCxDQUFMLEVBQXlCO0FBQ3ZCekcsYUFBT00sTUFBUCxDQUFjLDZFQUFkOztBQUNBLGFBQU9tRyxHQUFQO0FBQ0Q7O0FBRUQsUUFBSSxDQUFDLEtBQUs5RixPQUFMLENBQWEyRixJQUFiLENBQUwsRUFBeUI7QUFDdkJ0RyxhQUFPTSxNQUFQLENBQWMsNkVBQWQ7O0FBQ0EsYUFBT21HLEdBQVA7QUFDRDs7QUFFRCxVQUFNUSxTQUFTLEVBQWY7QUFDQVgsU0FBSzNCLE9BQUwsQ0FBY1gsR0FBRCxJQUFTO0FBQ3BCaUQsYUFBT2pELEdBQVAsSUFBY3lDLElBQUl6QyxHQUFKLENBQWQ7QUFDRCxLQUZEO0FBSUEsV0FBT2lELE1BQVA7QUFDRCxHQW5EYzs7QUFvRGZ0RyxVQUFROEYsR0FBUixFQUFhO0FBQ1gsV0FBT1IsTUFBTXRGLE9BQU4sQ0FBYzhGLEdBQWQsQ0FBUDtBQUNELEdBdERjOztBQXVEZm5FLFNBQU8sR0FBRzRFLElBQVYsRUFBZ0I7QUFBRTtBQUNoQixXQUFPYixPQUFPYyxNQUFQLENBQWMsRUFBZCxFQUFrQixHQUFHRCxJQUFyQixDQUFQO0FBQ0QsR0F6RGM7O0FBMERmRixRQUFNUCxHQUFOLEVBQVc7QUFDVCxRQUFJLENBQUMsS0FBS0ksUUFBTCxDQUFjSixHQUFkLENBQUwsRUFBeUIsT0FBT0EsR0FBUDtBQUN6QixXQUFPLEtBQUs5RixPQUFMLENBQWE4RixHQUFiLElBQW9CQSxJQUFJVyxLQUFKLEVBQXBCLEdBQWtDLEtBQUs5RSxNQUFMLENBQVltRSxHQUFaLENBQXpDO0FBQ0Q7O0FBN0RjLENBQWpCO0FBZ0VBLENBQUMsV0FBRCxFQUFjLFVBQWQsRUFBMEIsUUFBMUIsRUFBb0MsUUFBcEMsRUFBOEM5QixPQUE5QyxDQUF1RG5ELElBQUQsSUFBVTtBQUM5RGpCLFdBQVMsT0FBT2lCLElBQWhCLElBQXdCLFVBQVVpRixHQUFWLEVBQWU7QUFDckMsV0FBT0osT0FBT3JFLFNBQVAsQ0FBaUJxRixRQUFqQixDQUEwQmxCLElBQTFCLENBQStCTSxHQUEvQixNQUF3QyxhQUFhakYsSUFBYixHQUFvQixHQUFuRTtBQUNELEdBRkQ7QUFHRCxDQUpELEUiLCJmaWxlIjoiL3BhY2thZ2VzL29zdHJpb19mbG93LXJvdXRlci1leHRyYS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IFJvdXRlciAgICAgZnJvbSAnLi9yb3V0ZXIuanMnO1xuaW1wb3J0IFJvdXRlICAgICAgZnJvbSAnLi9yb3V0ZS5qcyc7XG5pbXBvcnQgR3JvdXAgICAgICBmcm9tICcuL2dyb3VwLmpzJztcbmltcG9ydCAnLi9wbHVnaW5zL2Zhc3QtcmVuZGVyLmpzJztcblxuaWYgKFBhY2thZ2VbJ21ldGVvcmhhY2tzOmluamVjdC1kYXRhJ10pIHtcbiAgTWV0ZW9yLl9kZWJ1ZygnYG1ldGVvcmhhY2tzOmluamVjdC1kYXRhYCBpcyBkZXByZWNhdGVkLCBwbGVhc2UgcmVtb3ZlIGl0IGFuZCBpbnN0YWxsIGl0cyBzdWNjZXNzb3IgLSBgc3RhcmluZ2F0bGlnaHRzOmluamVjdC1kYXRhYCcpO1xuICBNZXRlb3IuX2RlYnVnKCdtZXRlb3IgcmVtb3ZlIG1ldGVvcmhhY2tzOmluamVjdC1kYXRhJyk7XG4gIE1ldGVvci5fZGVidWcoJ21ldGVvciBhZGQgc3RhcmluZ2F0bGlnaHRzOmluamVjdC1kYXRhJyk7XG59XG5cbmlmIChQYWNrYWdlWydtZXRlb3JoYWNrczpmYXN0LXJlbmRlciddKSB7XG4gIE1ldGVvci5fZGVidWcoJ2BtZXRlb3JoYWNrczpmYXN0LXJlbmRlcmAgaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHJlbW92ZSBpdCBhbmQgaW5zdGFsbCBpdHMgc3VjY2Vzc29yIC0gYHN0YXJpbmdhdGxpZ2h0czpmYXN0LXJlbmRlcmAnKTtcbiAgTWV0ZW9yLl9kZWJ1ZygnbWV0ZW9yIHJlbW92ZSBtZXRlb3JoYWNrczpmYXN0LXJlbmRlcicpO1xuICBNZXRlb3IuX2RlYnVnKCdtZXRlb3IgYWRkIHN0YXJpbmdhdGxpZ2h0czpmYXN0LXJlbmRlcicpO1xufVxuXG5jb25zdCBUcmlnZ2VycyA9IHt9O1xuY29uc3QgQmxhemVSZW5kZXJlciA9IHt9O1xuXG5jb25zdCBGbG93Um91dGVyID0gbmV3IFJvdXRlcigpO1xuRmxvd1JvdXRlci5Sb3V0ZXIgPSBSb3V0ZXI7XG5GbG93Um91dGVyLlJvdXRlID0gUm91dGU7XG5cbmV4cG9ydCB7IEZsb3dSb3V0ZXIsIFJvdXRlciwgUm91dGUsIEdyb3VwLCBUcmlnZ2VycywgQmxhemVSZW5kZXJlciB9O1xuIiwiaW1wb3J0IHsgX2hlbHBlcnMgfSBmcm9tICcuLy4uL2xpYi9faGVscGVycy5qcyc7XG5cbmNvbnN0IG1ha2VUcmlnZ2VyID0gKHRyaWdnZXIpID0+IHtcbiAgaWYgKF9oZWxwZXJzLmlzRnVuY3Rpb24odHJpZ2dlcikpIHtcbiAgICByZXR1cm4gW3RyaWdnZXJdO1xuICB9IGVsc2UgaWYgKCFfaGVscGVycy5pc0FycmF5KHRyaWdnZXIpKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG5cbiAgcmV0dXJuIHRyaWdnZXI7XG59O1xuXG5jb25zdCBtYWtlVHJpZ2dlcnMgPSAoX2Jhc2UsIF90cmlnZ2VycykgPT4ge1xuICBpZiAoKCFfYmFzZSAmJiAhX3RyaWdnZXJzKSkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICByZXR1cm4gbWFrZVRyaWdnZXIoX2Jhc2UpLmNvbmNhdChtYWtlVHJpZ2dlcihfdHJpZ2dlcnMpKTtcbn07XG5cbmNsYXNzIEdyb3VwIHtcbiAgY29uc3RydWN0b3Iocm91dGVyLCBvcHRpb25zID0ge30sIHBhcmVudCkge1xuICAgIGlmIChvcHRpb25zLnByZWZpeCAmJiAhL15cXC8vLnRlc3Qob3B0aW9ucy5wcmVmaXgpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ2dyb3VwXFwncyBwcmVmaXggbXVzdCBzdGFydCB3aXRoIFwiL1wiJyk7XG4gICAgfVxuXG4gICAgdGhpcy5fcm91dGVyID0gcm91dGVyO1xuICAgIHRoaXMucHJlZml4ID0gb3B0aW9ucy5wcmVmaXggfHwgJyc7XG4gICAgdGhpcy5uYW1lID0gb3B0aW9ucy5uYW1lO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG5cbiAgICB0aGlzLl90cmlnZ2Vyc0VudGVyID0gbWFrZVRyaWdnZXJzKG9wdGlvbnMudHJpZ2dlcnNFbnRlciwgdGhpcy5fdHJpZ2dlcnNFbnRlcik7XG4gICAgdGhpcy5fdHJpZ2dlcnNFeGl0ICA9IG1ha2VUcmlnZ2Vycyh0aGlzLl90cmlnZ2Vyc0V4aXQsIG9wdGlvbnMudHJpZ2dlcnNFeGl0KTtcblxuICAgIHRoaXMuX3N1YnNjcmlwdGlvbnMgPSBvcHRpb25zLnN1YnNjcmlwdGlvbnMgfHwgRnVuY3Rpb24ucHJvdG90eXBlO1xuXG4gICAgdGhpcy5wYXJlbnQgPSBwYXJlbnQ7XG4gICAgaWYgKHRoaXMucGFyZW50KSB7XG4gICAgICB0aGlzLnByZWZpeCA9IHBhcmVudC5wcmVmaXggKyB0aGlzLnByZWZpeDtcbiAgICAgIHRoaXMuX3RyaWdnZXJzRW50ZXIgPSBtYWtlVHJpZ2dlcnMocGFyZW50Ll90cmlnZ2Vyc0VudGVyLCB0aGlzLl90cmlnZ2Vyc0VudGVyKTtcbiAgICAgIHRoaXMuX3RyaWdnZXJzRXhpdCAgPSBtYWtlVHJpZ2dlcnModGhpcy5fdHJpZ2dlcnNFeGl0LCBwYXJlbnQuX3RyaWdnZXJzRXhpdCk7XG4gICAgfVxuICB9XG5cbiAgcm91dGUoX3BhdGhEZWYsIG9wdGlvbnMgPSB7fSwgX2dyb3VwKSB7XG4gICAgaWYgKCEvXlxcLy8udGVzdChfcGF0aERlZikpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcigncm91dGVcXCdzIHBhdGggbXVzdCBzdGFydCB3aXRoIFwiL1wiJyk7XG4gICAgfVxuXG4gICAgY29uc3QgZ3JvdXAgICA9IF9ncm91cCB8fCB0aGlzO1xuICAgIGNvbnN0IHBhdGhEZWYgPSB0aGlzLnByZWZpeCArIF9wYXRoRGVmO1xuXG4gICAgb3B0aW9ucy50cmlnZ2Vyc0VudGVyID0gbWFrZVRyaWdnZXJzKHRoaXMuX3RyaWdnZXJzRW50ZXIsIG9wdGlvbnMudHJpZ2dlcnNFbnRlcik7XG4gICAgb3B0aW9ucy50cmlnZ2Vyc0V4aXQgID0gbWFrZVRyaWdnZXJzKG9wdGlvbnMudHJpZ2dlcnNFeGl0LCB0aGlzLl90cmlnZ2Vyc0V4aXQpO1xuXG4gICAgcmV0dXJuIHRoaXMuX3JvdXRlci5yb3V0ZShwYXRoRGVmLCBfaGVscGVycy5leHRlbmQoX2hlbHBlcnMub21pdCh0aGlzLm9wdGlvbnMsIFsndHJpZ2dlcnNFbnRlcicsICd0cmlnZ2Vyc0V4aXQnLCAnc3Vic2NyaXB0aW9ucycsICdwcmVmaXgnLCAnd2FpdE9uJywgJ25hbWUnLCAndGl0bGUnLCAndGl0bGVQcmVmaXgnLCAnbGluaycsICdzY3JpcHQnLCAnbWV0YSddKSwgb3B0aW9ucyksIGdyb3VwKTtcbiAgfVxuXG4gIGdyb3VwKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IEdyb3VwKHRoaXMuX3JvdXRlciwgb3B0aW9ucywgdGhpcyk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgR3JvdXA7XG4iLCJjbGFzcyBSb3V0ZSB7XG4gIGNvbnN0cnVjdG9yKHJvdXRlciwgcGF0aERlZiwgb3B0aW9ucyA9IHt9KSB7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLm5hbWUgPSBvcHRpb25zLm5hbWU7XG4gICAgdGhpcy5wYXRoRGVmID0gcGF0aERlZjtcblxuICAgIC8vIFJvdXRlLnBhdGggaXMgZGVwcmVjYXRlZCBhbmQgd2lsbCBiZSByZW1vdmVkIGluIDMuMFxuICAgIHRoaXMucGF0aCA9IHBhdGhEZWY7XG5cbiAgICB0aGlzLmFjdGlvbiA9IG9wdGlvbnMuYWN0aW9uIHx8IEZ1bmN0aW9uLnByb3RvdHlwZTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBvcHRpb25zLnN1YnNjcmlwdGlvbnMgfHwgRnVuY3Rpb24ucHJvdG90eXBlO1xuICAgIHRoaXMuX3N1YnNNYXAgPSB7fTtcbiAgfVxuXG5cbiAgcmVnaXN0ZXIobmFtZSwgc3ViKSB7XG4gICAgdGhpcy5fc3Vic01hcFtuYW1lXSA9IHN1YjtcbiAgfVxuXG5cbiAgc3Vic2NyaXB0aW9uKG5hbWUpIHtcbiAgICByZXR1cm4gdGhpcy5fc3Vic01hcFtuYW1lXTtcbiAgfVxuXG5cbiAgbWlkZGxld2FyZSgpIHtcbiAgICAvLyA/XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgUm91dGU7XG4iLCJpbXBvcnQgUm91dGUgICAgICAgIGZyb20gJy4vcm91dGUuanMnO1xuaW1wb3J0IEdyb3VwICAgICAgICBmcm9tICcuL2dyb3VwLmpzJztcbmltcG9ydCB7IE1ldGVvciB9ICAgZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBfaGVscGVycyB9IGZyb20gJy4vLi4vbGliL19oZWxwZXJzLmpzJztcblxuY29uc3QgcXMgPSByZXF1aXJlKCdxcycpO1xuXG5jbGFzcyBSb3V0ZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnBhdGhSZWdFeHAgPSAvKDpbXFx3XFwoXFwpXFxcXFxcK1xcKlxcLlxcP1xcW1xcXVxcLV0rKSsvZztcbiAgICB0aGlzLl9yb3V0ZXMgPSBbXTtcbiAgICB0aGlzLl9yb3V0ZXNNYXAgPSB7fTtcbiAgICB0aGlzLnN1YnNjcmlwdGlvbnMgPSBGdW5jdGlvbi5wcm90b3R5cGU7XG5cbiAgICAvLyBob2xkcyBvblJvdXRlIGNhbGxiYWNrc1xuICAgIHRoaXMuX29uUm91dGVDYWxsYmFja3MgPSBbXTtcblxuICAgIHRoaXMudHJpZ2dlcnMgPSB7XG4gICAgICBlbnRlcigpIHtcbiAgICAgICAgLy8gY2xpZW50IG9ubHlcbiAgICAgIH0sXG4gICAgICBleGl0KCkge1xuICAgICAgICAvLyBjbGllbnQgb25seVxuICAgICAgfVxuICAgIH07XG4gIH1cblxuICByb3V0ZShwYXRoRGVmLCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAoIS9eXFwvLiovLnRlc3QocGF0aERlZikgJiYgcGF0aERlZiAhPT0gJyonKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ3JvdXRlXFwncyBwYXRoIG11c3Qgc3RhcnQgd2l0aCBcIi9cIicpO1xuICAgIH1cblxuICAgIGNvbnN0IHJvdXRlID0gbmV3IFJvdXRlKHRoaXMsIHBhdGhEZWYsIG9wdGlvbnMpO1xuICAgIHRoaXMuX3JvdXRlcy5wdXNoKHJvdXRlKTtcblxuICAgIGlmIChvcHRpb25zLm5hbWUpIHtcbiAgICAgIHRoaXMuX3JvdXRlc01hcFtvcHRpb25zLm5hbWVdID0gcm91dGU7XG4gICAgfVxuXG4gICAgdGhpcy5fdHJpZ2dlclJvdXRlUmVnaXN0ZXIocm91dGUpO1xuICAgIHJldHVybiByb3V0ZTtcbiAgfVxuXG4gIGdyb3VwKG9wdGlvbnMpIHtcbiAgICByZXR1cm4gbmV3IEdyb3VwKHRoaXMsIG9wdGlvbnMpO1xuICB9XG5cbiAgcGF0aChfcGF0aERlZiwgZmllbGRzID0ge30sIHF1ZXJ5UGFyYW1zKSB7XG4gICAgbGV0IHBhdGhEZWYgPSBfcGF0aERlZjtcbiAgICBpZiAodGhpcy5fcm91dGVzTWFwW3BhdGhEZWZdKSB7XG4gICAgICBwYXRoRGVmID0gdGhpcy5fcm91dGVzTWFwW3BhdGhEZWZdLnBhdGg7XG4gICAgfVxuXG4gICAgbGV0IHBhdGggPSBwYXRoRGVmLnJlcGxhY2UodGhpcy5wYXRoUmVnRXhwLCAoX2tleSkgPT4ge1xuICAgICAgY29uc3QgZmlyc3RSZWdleHBDaGFyID0gX2tleS5pbmRleE9mKCcoJyk7XG4gICAgICAvLyBnZXQgdGhlIGNvbnRlbnQgYmVoaW5kIDogYW5kIChcXFxcZCsvKVxuICAgICAgbGV0IGtleSA9IF9rZXkuc3Vic3RyaW5nKDEsIChmaXJzdFJlZ2V4cENoYXIgPiAwKSA/IGZpcnN0UmVnZXhwQ2hhciA6IHVuZGVmaW5lZCk7XG4gICAgICAvLyByZW1vdmUgKz8qXG4gICAgICBrZXkgPSBrZXkucmVwbGFjZSgvW1xcK1xcKlxcP10rL2csICcnKTtcblxuICAgICAgcmV0dXJuIGZpZWxkc1trZXldIHx8ICcnO1xuICAgIH0pO1xuXG4gICAgcGF0aCA9IHBhdGgucmVwbGFjZSgvXFwvXFwvKy9nLCAnLycpOyAvLyBSZXBsYWNlIG11bHRpcGxlIHNsYXNoZXMgd2l0aCBzaW5nbGUgc2xhc2hcblxuICAgIC8vIHJlbW92ZSB0cmFpbGluZyBzbGFzaFxuICAgIC8vIGJ1dCBrZWVwIHRoZSByb290IHNsYXNoIGlmIGl0J3MgdGhlIG9ubHkgb25lXG4gICAgcGF0aCA9IHBhdGgubWF0Y2goL15cXC97MX0kLykgPyBwYXRoIDogcGF0aC5yZXBsYWNlKC9cXC8kLywgJycpO1xuXG4gICAgY29uc3Qgc3RyUXVlcnlQYXJhbXMgPSBxcy5zdHJpbmdpZnkocXVlcnlQYXJhbXMgfHwge30pO1xuICAgIGlmKHN0clF1ZXJ5UGFyYW1zKSB7XG4gICAgICBwYXRoICs9ICc/JyArIHN0clF1ZXJ5UGFyYW1zO1xuICAgIH1cblxuICAgIHJldHVybiBwYXRoO1xuICB9XG5cbiAgb25Sb3V0ZVJlZ2lzdGVyKGNiKSB7XG4gICAgdGhpcy5fb25Sb3V0ZUNhbGxiYWNrcy5wdXNoKGNiKTtcbiAgfVxuXG4gIF90cmlnZ2VyUm91dGVSZWdpc3RlcihjdXJyZW50Um91dGUpIHtcbiAgICAvLyBXZSBzaG91bGQgb25seSBuZWVkIHRvIHNlbmQgYSBzYWZlIHNldCBvZiBmaWVsZHMgb24gdGhlIHJvdXRlXG4gICAgLy8gb2JqZWN0LlxuICAgIC8vIFRoaXMgaXMgbm90IHRvIGhpZGUgd2hhdCdzIGluc2lkZSB0aGUgcm91dGUgb2JqZWN0LCBidXQgdG8gc2hvd1xuICAgIC8vIHRoZXNlIGFyZSB0aGUgcHVibGljIEFQSXNcbiAgICBjb25zdCByb3V0ZVB1YmxpY0FwaSA9IF9oZWxwZXJzLnBpY2soY3VycmVudFJvdXRlLCBbJ25hbWUnLCAncGF0aERlZicsICdwYXRoJ10pO1xuICAgIHJvdXRlUHVibGljQXBpLm9wdGlvbnMgPSBfaGVscGVycy5vbWl0KGN1cnJlbnRSb3V0ZS5vcHRpb25zLCBbJ3RyaWdnZXJzRW50ZXInLCAndHJpZ2dlcnNFeGl0JywgJ2FjdGlvbicsICdzdWJzY3JpcHRpb25zJywgJ25hbWUnXSk7XG5cbiAgICB0aGlzLl9vblJvdXRlQ2FsbGJhY2tzLmZvckVhY2goKGNiKSA9PiB7XG4gICAgICBjYihyb3V0ZVB1YmxpY0FwaSk7XG4gICAgfSk7XG4gIH1cblxuXG4gIGdvKCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIGN1cnJlbnQoKSB7XG4gICAgLy8gY2xpZW50IG9ubHlcbiAgfVxuXG4gIG1pZGRsZXdhcmUoKSB7XG4gICAgLy8gY2xpZW50IG9ubHlcbiAgfVxuXG5cbiAgZ2V0U3RhdGUoKSB7XG4gICAgLy8gY2xpZW50IG9ubHlcbiAgfVxuXG5cbiAgZ2V0QWxsU3RhdGVzKCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIHNldFN0YXRlKCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIHJlbW92ZVN0YXRlKCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIGNsZWFyU3RhdGVzKCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIHJlYWR5KCkge1xuICAgIC8vIGNsaWVudCBvbmx5XG4gIH1cblxuXG4gIGluaXRpYWxpemUoKSB7XG4gICAgLy8gY2xpZW50IG9ubHlcbiAgfVxuXG4gIHdhaXQoKSB7XG4gICAgLy8gY2xpZW50IG9ubHlcbiAgfVxuXG4gIHVybCgpIHtcbiAgICAvLyBXZSBuZWVkIHRvIHJlbW92ZSB0aGUgbGVhZGluZyBiYXNlIHBhdGgsIG9yIFwiL1wiLCBhcyBpdCB3aWxsIGJlIGluc2VydGVkXG4gICAgLy8gYXV0b21hdGljYWxseSBieSBgTWV0ZW9yLmFic29sdXRlVXJsYCBhcyBkb2N1bWVudGVkIGluOlxuICAgIC8vIGh0dHA6Ly9kb2NzLm1ldGVvci5jb20vIy9mdWxsL21ldGVvcl9hYnNvbHV0ZXVybFxuICAgIHJldHVybiBNZXRlb3IuYWJzb2x1dGVVcmwodGhpcy5wYXRoLmFwcGx5KHRoaXMsIGFyZ3VtZW50cykucmVwbGFjZShuZXcgUmVnRXhwKCdeJyArICgnLycgKyAodGhpcy5fYmFzZVBhdGggfHwgJycpICsgJy8nKS5yZXBsYWNlKC9cXC9cXC8rL2csICcvJykpLCAnJykpO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IFJvdXRlcjtcbiIsImltcG9ydCB7IE1ldGVvciB9ICAgICBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IF9oZWxwZXJzIH0gICBmcm9tICcuLy4uLy4uL2xpYi9faGVscGVycy5qcyc7XG5pbXBvcnQgeyBGbG93Um91dGVyIH0gZnJvbSAnLi4vX2luaXQuanMnO1xuXG5pZighUGFja2FnZVsnc3RhcmluZ2F0bGlnaHRzOmZhc3QtcmVuZGVyJ10pIHtcbiAgcmV0dXJuO1xufVxuXG5jb25zdCBGYXN0UmVuZGVyID0gUGFja2FnZVsnc3RhcmluZ2F0bGlnaHRzOmZhc3QtcmVuZGVyJ10uRmFzdFJlbmRlcjtcblxuY29uc3Qgc2V0dXBGYXN0UmVuZGVyID0gKCkgPT4ge1xuICBGbG93Um91dGVyLl9yb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IHtcbiAgICBpZiAocm91dGUucGF0aERlZiA9PT0gJyonKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgRmFzdFJlbmRlci5yb3V0ZShyb3V0ZS5wYXRoRGVmLCBmdW5jdGlvbiAocm91dGVQYXJhbXMsIHBhdGgpIHtcbiAgICAgIC8vIGFueW9uZSB1c2luZyBNZXRlb3Iuc3Vic2NyaWJlIGZvciBzb21ldGhpbmcgZWxzZT9cbiAgICAgIGNvbnN0IG1ldGVvclN1YnNjcmliZSA9IE1ldGVvci5zdWJzY3JpYmU7XG4gICAgICBNZXRlb3Iuc3Vic2NyaWJlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShhcmd1bWVudHMpO1xuICAgICAgfTtcblxuICAgICAgcm91dGUuX3N1YnNNYXAgPSB7fTtcbiAgICAgIEZsb3dSb3V0ZXIuc3Vic2NyaXB0aW9ucy5jYWxsKHJvdXRlLCBwYXRoKTtcbiAgICAgIGlmIChyb3V0ZS5zdWJzY3JpcHRpb25zKSB7XG4gICAgICAgIHJvdXRlLnN1YnNjcmlwdGlvbnMoX2hlbHBlcnMub21pdChyb3V0ZVBhcmFtcywgWydxdWVyeSddKSwgcm91dGVQYXJhbXMucXVlcnkpO1xuICAgICAgfVxuXG4gICAgICBPYmplY3Qua2V5cyhyb3V0ZS5fc3Vic01hcCkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgIHRoaXMuc3Vic2NyaWJlLmFwcGx5KHRoaXMsIHJvdXRlLl9zdWJzTWFwW2tleV0pO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIHJlc3RvcmUgTWV0ZW9yLnN1YnNjcmliZSwgLi4uIG9uIHNlcnZlciBzaWRlXG4gICAgICBNZXRlb3Iuc3Vic2NyaWJlID0gbWV0ZW9yU3Vic2NyaWJlO1xuICAgIH0pO1xuICB9KTtcbn07XG5cbi8vIGhhY2sgdG8gcnVuIGFmdGVyIGV2ZXJ5dGhpbmcgZWxzZSBvbiBzdGFydHVwXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIE1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgICBzZXR1cEZhc3RSZW5kZXIoKTtcbiAgfSk7XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuXG5jb25zdCBfaGVscGVycyA9IHtcbiAgaXNFbXB0eShvYmopIHsgLy8gMVxuICAgIGlmIChvYmogPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaXNBcnJheShvYmopIHx8IHRoaXMuaXNTdHJpbmcob2JqKSB8fCB0aGlzLmlzQXJndW1lbnRzKG9iaikpIHtcbiAgICAgIHJldHVybiBvYmoubGVuZ3RoID09PSAwO1xuICAgIH1cblxuICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLmxlbmd0aCA9PT0gMDtcbiAgfSxcbiAgaXNPYmplY3Qob2JqKSB7XG4gICAgY29uc3QgdHlwZSA9IHR5cGVvZiBvYmo7XG4gICAgcmV0dXJuIHR5cGUgPT09ICdmdW5jdGlvbicgfHwgdHlwZSA9PT0gJ29iamVjdCcgJiYgISFvYmo7XG4gIH0sXG4gIG9taXQob2JqLCBrZXlzKSB7IC8vIDEwXG4gICAgaWYgKCF0aGlzLmlzT2JqZWN0KG9iaikpIHtcbiAgICAgIE1ldGVvci5fZGVidWcoJ1tvc3RyaW86Zmxvdy1yb3V0ZXItZXh0cmFdIFtfaGVscGVycy5vbWl0XSBGaXJzdCBhcmd1bWVudCBtdXN0IGJlIGFuIE9iamVjdCcpO1xuICAgICAgcmV0dXJuIG9iajtcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuaXNBcnJheShrZXlzKSkge1xuICAgICAgTWV0ZW9yLl9kZWJ1ZygnW29zdHJpbzpmbG93LXJvdXRlci1leHRyYV0gW19oZWxwZXJzLm9taXRdIFNlY29uZCBhcmd1bWVudCBtdXN0IGJlIGFuIEFycmF5Jyk7XG4gICAgICByZXR1cm4gb2JqO1xuICAgIH1cblxuICAgIGNvbnN0IGNvcHkgPSB0aGlzLmNsb25lKG9iaik7XG4gICAga2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGRlbGV0ZSBjb3B5W2tleV07XG4gICAgfSk7XG5cbiAgICByZXR1cm4gY29weTtcbiAgfSxcbiAgcGljayhvYmosIGtleXMpIHsgLy8gMlxuICAgIGlmICghdGhpcy5pc09iamVjdChvYmopKSB7XG4gICAgICBNZXRlb3IuX2RlYnVnKCdbb3N0cmlvOmZsb3ctcm91dGVyLWV4dHJhXSBbX2hlbHBlcnMub21pdF0gRmlyc3QgYXJndW1lbnQgbXVzdCBiZSBhbiBPYmplY3QnKTtcbiAgICAgIHJldHVybiBvYmo7XG4gICAgfVxuXG4gICAgaWYgKCF0aGlzLmlzQXJyYXkoa2V5cykpIHtcbiAgICAgIE1ldGVvci5fZGVidWcoJ1tvc3RyaW86Zmxvdy1yb3V0ZXItZXh0cmFdIFtfaGVscGVycy5vbWl0XSBTZWNvbmQgYXJndW1lbnQgbXVzdCBiZSBhbiBBcnJheScpO1xuICAgICAgcmV0dXJuIG9iajtcbiAgICB9XG5cbiAgICBjb25zdCBwaWNrZWQgPSB7fTtcbiAgICBrZXlzLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgcGlja2VkW2tleV0gPSBvYmpba2V5XTtcbiAgICB9KTtcblxuICAgIHJldHVybiBwaWNrZWQ7XG4gIH0sXG4gIGlzQXJyYXkob2JqKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkob2JqKTtcbiAgfSxcbiAgZXh0ZW5kKC4uLm9ianMpIHsgLy8gNFxuICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCAuLi5vYmpzKTtcbiAgfSxcbiAgY2xvbmUob2JqKSB7XG4gICAgaWYgKCF0aGlzLmlzT2JqZWN0KG9iaikpIHJldHVybiBvYmo7XG4gICAgcmV0dXJuIHRoaXMuaXNBcnJheShvYmopID8gb2JqLnNsaWNlKCkgOiB0aGlzLmV4dGVuZChvYmopO1xuICB9XG59O1xuXG5bJ0FyZ3VtZW50cycsICdGdW5jdGlvbicsICdTdHJpbmcnLCAnUmVnRXhwJ10uZm9yRWFjaCgobmFtZSkgPT4ge1xuICBfaGVscGVyc1snaXMnICsgbmFtZV0gPSBmdW5jdGlvbiAob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvYmopID09PSAnW29iamVjdCAnICsgbmFtZSArICddJztcbiAgfTtcbn0pO1xuXG5leHBvcnQgeyBfaGVscGVycyB9O1xuIl19
