def contact_customer():
    print("contacting customer..")
